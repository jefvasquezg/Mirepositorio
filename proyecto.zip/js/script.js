

function validarInformacion(){
    
    let datos=new Object();

    var nombre=document.getElementById("name_contact").value; // obtengo el valor que obtiene el input nombre
    var correo=document.getElementById("email_contact").value; // obtengo el valor que obtiene el input correo
    var telefono=document.getElementById("tel_contact").value; // obtengo el valor que obtiene el input telefono
    var tipo_identificacion=document.getElementById("tipo_identificacion").value; // obtengo el valor que obtiene el input tipo identificacion
    var comentario=document.getElementById("commit_contact").value; // obtengo el valor que obtiene el input comentario o descripcion

    // vamos a evaluar si el nombre tiene algun texto o caracter
    if(nombre.length < 5){
        document.getElementById("msgNombre").innerText="Ingrese un Nombre Valido";
    }else{
        document.getElementById("msgNombre").innerText="Ok";
        datos["Nombre"]=nombre;
    }

    //se evalua que el correo tenga texto y formato

    if(correo.length > 0){
        var regex =  /^(([^<>()\[\]\\.,;:\s@”]+(\.[^<>()\[\]\\.,;:\s@”]+)*)|(“.+”))@((\[[0–9]{1,3}\.[0–9]{1,3}\.[0–9]{1,3}\.[0–9]{1,3}])|(([a-zA-Z\-0–9]+\.)+[a-zA-Z]{2,}))$/;
        if(!regex.test(correo)){
            document.getElementById("msgCorreo").innerText="Correo no Valido";
        }
        else{
            document.getElementById("msgCorreo").innerText="OK";
            datos["Correo"]=correo;
        }
    }else{
        document.getElementById("msgCorreo").innerText="Correo Obligatorio";
    }

    // evaluo si el telefono tiene mas de 10 caracteres

    if(telefono.length < 10){
        document.getElementById("msgNumero").innerText="Numero Telefono no es correcto";
    }else{
        document.getElementById("msgNumero").innerText="OK";
        datos["Telefono"]=telefono;
    }

    //evaluo tipo de identificacion

    if(tipo_identificacion==0){
        document.getElementById("msgIdentificacion").innerText="Tipo de identificacion no valida";
    }else{
        document.getElementById("msgIdentificacion").innerText="OK";
        datos["Tipo_identificacion"]=tipo_identificacion;
    }

    // evaluo descripcion

    if(comentario.length <= 0){
        document.getElementById("msgDescripcion").innerText="El comentario es obligatorio";
    }else{
        document.getElementById("msgDescripcion").innerText="OK";
        datos["Comentario"]=comentario;
    }
    
    console.log(datos);
}

