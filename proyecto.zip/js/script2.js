window.addEventListener('DOMContentLoaded', inicio, false);

function inicio() {
  for (var x = 0; x <= 9; x++) {
    document.getElementById('boton' + x).addEventListener('click', presion, false);
  }
}

function presion(evt) {
  document.getElementById('resultado').innerHTML =
    document.getElementById('resultado').innerHTML + evt.target.value;
    document.getElementById('resultado').setAttribute("class","letra");

}